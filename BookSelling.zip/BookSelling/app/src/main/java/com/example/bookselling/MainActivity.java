package com.example.bookselling;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookselling.Model.Category;
import com.example.bookselling.Model.Product;
import com.example.bookselling.MyAdapter.ProductAdapter;
import com.example.bookselling.Service.MyRetrofit;
import com.example.bookselling.Service.ProductService;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ProductService productService;
    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private EditText etSearch;
    private ImageButton btnCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView.findViewById(R.id.recycler_view);
        // Khởi tạo Retrofit Service
        productService = MyRetrofit.getClient().create(ProductService.class);

        // Thực hiện cuộc gọi API và xử lý kết quả
        Call<List<Map<String, Object>>> call = productService.getAllProducts();
        call.enqueue(new Callback<List<Map<String, Object>>>() {
            @Override
            public void onResponse(Call<List<Map<String, Object>>> call, Response<List<Map<String, Object>>> response) {
                if (response.isSuccessful()) {
                    List<Map<String, Object>> productList = response.body();
                    // Xử lý danh sách sản phẩm ở đây
                    productAdapter = new ProductAdapter(MainActivity.this,productList);
                    recyclerView.setAdapter(productAdapter);
                } else {
                    // Xử lý khi không thành công
                }
            }
            @Override
            public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                // Xử lý khi gặp lỗi kết nối
            }
        });

        Category category = new Category();
        productList = new ArrayList<>();
        productList.add(new Product("Kiến Trúc Máy Tính", "Description 1","FUROFUSHI","Kim Dong", 10.99,category));


        // Khởi tạo RecyclerView và ProductAdapter
        recyclerView = findViewById(R.id.recycler_view);
//        productAdapter = new ProductAdapter(productList, this);

        // Thiết lập LayoutManager cho RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Thiết lập Adapter cho RecyclerView
        recyclerView.setAdapter(productAdapter);
    }

    private void performSearch(String keyword) {

    }

}