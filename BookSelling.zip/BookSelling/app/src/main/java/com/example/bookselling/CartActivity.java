package com.example.bookselling;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookselling.Model.Product;

import java.util.List;

public class CartActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private CartAdapter cartAdapter;
    private List<Product> cartProductList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity);

        recyclerView = findViewById(R.id.recycler_view_cart);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Get the current products in the cart
        cartProductList = CartManager.getInstance().getCartItemList();

        // Check if the cart is not empty
        if(cartProductList != null && !cartProductList.isEmpty()) {
            // Set up the recyclerView with the cart adapter
            cartAdapter = new CartAdapter(this, cartProductList);
            recyclerView.setAdapter(cartAdapter);
            cartAdapter.notifyDataSetChanged();
        } else {
            // Handle empty cart scenario, maybe show a message to the user
            // For example, "Your cart is empty!" or redirect back to product list
        }
    }
}
