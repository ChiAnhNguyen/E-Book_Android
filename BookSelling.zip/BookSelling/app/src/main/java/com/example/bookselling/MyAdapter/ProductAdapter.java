package com.example.bookselling.MyAdapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookselling.Model.Category;
import com.example.bookselling.Model.Product;
import com.example.bookselling.R;

import java.util.List;
import java.util.Map;

import retrofit2.Callback;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {
    private List<Map<String, Object>> productList;
    private Context context;

    public ProductAdapter(Context context, List<Map<String, Object>> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Map<String, Object> productMap = productList.get(position);
        Category category = new Category();
        Product product = (Product) productMap.get("product");
        String categoryName = ((Category) productMap.get("category")).getCategoryName();
        byte[] imageData = (byte[]) productMap.get("imageData");
        // Set thông tin của sản phẩm từ map
        product.setProductID((int) productMap.get("productID"));
        product.setProductName((String) productMap.get("productName"));
        product.setDescript((String) productMap.get("Descript"));
        product.setAuthor((String) productMap.get("author"));
        product.setPublisher((String) productMap.get("publisher"));
        product.setPrice((double) productMap.get("price"));
        // Set thông tin của danh mục từ map
        category.setCategoryName((String) productMap.get("categoryName"));
        holder.textViewProductName.setText(product.getProductName());
        holder.textViewCategoryName.setText(categoryName);
        holder.textViewProductDescription.setText(product.getDescript());
        holder.textViewAuthor.setText("Author: " + product.getAuthor());
        holder.textViewPublisher.setText("Publisher: " + product.getPublisher());
        holder.textViewProductPrice.setText(String.format("Price: $%.2f", product.getPrice()));

        // Convert byte array to Bitmap
        Bitmap bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
        holder.imageViewProduct.setImageBitmap(bitmap);

        // Set click listener for "Add to Cart" button
        holder.buttonAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement your logic for adding product to cart
            }
        });

        // Set click listener for "Buy Now" button
        holder.buttonBuyNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement your logic for buying product
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewProduct;
        TextView textViewProductName;
        TextView textViewCategoryName;
        TextView textViewProductDescription;
        TextView textViewAuthor;
        TextView textViewPublisher;
        TextView textViewProductPrice;
        Button buttonAddToCart;
        Button buttonBuyNow;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewProduct = itemView.findViewById(R.id.imageViewProduct);
            textViewProductName = itemView.findViewById(R.id.textViewProductName);
            textViewCategoryName = itemView.findViewById(R.id.textViewCategoryName);
            textViewProductDescription = itemView.findViewById(R.id.textViewProductDescription);
            textViewAuthor = itemView.findViewById(R.id.textViewAuthor);
            textViewPublisher = itemView.findViewById(R.id.textViewPublisher);
            textViewProductPrice = itemView.findViewById(R.id.textViewProductPrice);
            buttonAddToCart = itemView.findViewById(R.id.buttonAddToCart);
            buttonBuyNow = itemView.findViewById(R.id.buttonBuyNow);
        }
    }
}